import { SaiAppPage } from './app.po';

describe('sai-app App', () => {
  let page: SaiAppPage;

  beforeEach(() => {
    page = new SaiAppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
