import { Component } from '@angular/core';
import { RouterModule, Router, Routes  } from '@angular/router';
@Component({
  selector: 'success',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  title = 'app';
  username;
  password;
  constructor( private router: Router) {  }
  submit() {
    if (this.password === '123456') {
      this.router.navigateByUrl('success');
    }else {
      alert('password not equal to 123456');
    }
  }
}
