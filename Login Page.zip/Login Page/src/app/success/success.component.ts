import { Component } from '@angular/core';
import { RouterModule, Router, Routes  } from '@angular/router';
@Component({
  selector: 'success',
  templateUrl: './success.component.html'
})
export class SuccessComponent {

  constructor( private router: Router) {

  }

}
