import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { SuccessComponent } from "./success/success.component";
import { LoginComponent } from "./login/login.component";
// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component: AppComponent,
    children: [
      { path: '', redirectTo : 'login', pathMatch: 'full' },
      { path: 'login', component: LoginComponent },
      { path: 'success', component: SuccessComponent }
    ]
  }
];

export const routing = RouterModule.forRoot(routes);
